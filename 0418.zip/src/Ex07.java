
public class Ex07 {
	public static void main(String[] args) {
		int a = 100;
		System.out.println("a = " + a);
		System.out.println("a = " + Integer.toBinaryString(a));
		int b = ~a; // 1의 보수를 구한다.
		System.out.println("b = " + b);
		System.out.println("b = " + Integer.toBinaryString(b));
		
		// 컴퓨터는 덧셈만하는 계산기이다. 뺄셈을 시키면 2의보수를 더해서 계산을 한다.
		int x = 10, y = 7;
		System.out.println(x + " - " + y + " = " + (x - y));
		System.out.println(x + " - " + y + " = " + (x + (~y + 1)));
		
		// 1의 보수  + 1  = 2의 보수
		
	}
}

import java.util.Scanner;

public class Ex09 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = 1;
		while(n!=0) {
			System.out.print("0~255사이의 정수입력(0은 종료)");
			n = sc.nextInt();
			if(n==0) continue;
			
			System.out.println(Integer.toBinaryString(n)); // 자바로 2진수로 출력
			// 프로그램으로 2진수 출력
			int mask = 0x80; // 8비트 중에서 최상위 1비트만 1인 이진수 : 1000 0000
			for(int i=0;i<8;i++) {// 8회 반복
				// 삼항연산자 : 연산 대상이 3개인 연산자.
				// 조건 ? 참인경우값 : 거짓인경우값
				System.out.print((mask & n) == mask ? "1" : "0");
				mask >>= 1;
			}
			System.out.println();
		}
		sc.close();
	}
}

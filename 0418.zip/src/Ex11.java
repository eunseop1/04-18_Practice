
public class Ex11 {
	public static void main(String[] args) {
		int color = 0xAABBCCDD;
		// 색상을 분리해보자
		int alpha = color >> 24 & 0x000000FF;
		System.out.println("ALPHA : " + alpha);
		System.out.println("ALPHA : " + Integer.toHexString(alpha));

		// 0으로 AND연산을하면 지워지고 1로 AND연산을하면 통과
		int red = color >> 16 & 0xFF;
		System.out.println("RED : " + Integer.toHexString(red));

		int green = color >> 8 & 0xFF;
		System.out.println("GREEN : " + Integer.toHexString(green));
		
		int blue = color & 0xFF;
		System.out.println("BLUE : " + Integer.toHexString(blue));
		
		// 색상을 결합	해보자
		// 0으로 OR연산을하면 통과 1로 OR연산을하면 설정
		int color2 = 0;
		color2 = color2 | alpha << 24;
		System.out.println("color2 : " + Integer.toHexString(color2));

		color2 = color2 | red << 16;
		System.out.println("color2 : " + Integer.toHexString(color2));
		
		color2 = color2 | green << 8;
		System.out.println("color2 : " + Integer.toHexString(color2));
		
		color2 = color2 | blue;
		System.out.println("color2 : " + Integer.toHexString(color2));
		
		// 빨간색만 지우고 싶다.
		color2 = color2 & 0xFF00FFFF;
		System.out.println("color2 : " + Integer.toHexString(color2));
		// 빨간색 값을 72로 바꾸고 싶다.
		color2 = color2 | 0x00720000;
		System.out.println("color2 : " + Integer.toHexString(color2));
		
		color2 = color2 | 0x00850000;
		System.out.println("color2 : " + Integer.toHexString(color2));
		
		
	}
}

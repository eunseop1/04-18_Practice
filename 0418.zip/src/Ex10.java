public class Ex10 {
	public static void main(String[] args) {
		
		int n = 0x2640;//0x4E00;// 0x0660;
		// 0000
		// 0110
		// 0110
		// 0000
		int mask = 0x8000; // 16비트 중에서 최상위 1비트만 1인 이진수 : 1000 0000 0000 0000
		for(int i=0;i<16;i++) {// 16회 반복
			// System.out.print((mask & n) == mask ? "1" : "0");
			System.out.print((mask & n) == mask ? "■" : "  ");
			mask >>= 1;
			// 4자리마다 줄바꿈
			if((i+1)%4==0) System.out.println();
		}
	}
}

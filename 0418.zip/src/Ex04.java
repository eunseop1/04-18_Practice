
public class Ex04 {
	public static void main(String[] args) {
		byte b = 126;
		System.out.println("b = " + b);
		b++;
		System.out.println("b = " + b);
		b++;
		System.out.println("b = " + b);
		
		b += 1;

		System.out.println("b = " + b);
		
		b = (byte) (b + 1);
		System.out.println("b = " + b);
	}
}
